import { BrowserRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { useEffect } from 'react';
import { useThemeStore } from './stores/themeStore';
import { useOrderStore } from './stores/orderStore';
import { useAuthStore } from './stores/authStore';
import { syncService } from './lib/syncService';
import { requestNotifyPermission } from './lib/browserNotify';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import WhatsAppFloat from './components/WhatsAppFloat';
import ToastContainer from './components/Toast';
import Home from './pages/Home';
import Services from './pages/Services';
import Book from './pages/Book';
import Track from './pages/Track';
import About from './pages/About';
import Contact from './pages/Contact';
import { LoginPage, SignupPage, ManagerLoginPage } from './pages/Auth';
import RiderDashboard from './pages/RiderDashboard';
import ManagerDashboard from './pages/ManagerDashboard';
import Profile from './pages/Profile';
import MyOrders from './pages/MyOrders';

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => { window.scrollTo(0, 0); }, [pathname]);
  return null;
}

// Routes where the map is full-screen — hide Footer & WhatsApp FAB
const FULL_SCREEN_ROUTES = ['/book', '/track'];

function AppContent() {
  const theme = useThemeStore(s => s.theme);
  const { pathname } = useLocation();
  const isFullScreen = FULL_SCREEN_ROUTES.includes(pathname);
  const user = useAuthStore(s => s.user);

  // ── Browser Notification permission: requested once, the first time
  //    a user is logged in. Graceful no-op if denied/unsupported. ────
  useEffect(() => {
    if (user) requestNotifyPermission();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  // ── Initialize global real-time synchronization (Supabase WebSocket + BroadcastChannel)
  useEffect(() => {
    syncService.init();
  }, []);

  // ── Periodic sweep: auto-cancel expired instant orders, start dispatch
  //    for scheduled orders coming due (~30 min before), and auto-cancel
  //    scheduled orders that missed their window. Runs app-wide so it
  //    works no matter which page is open. ─────────────────────────
  useEffect(() => {
    useOrderStore.getState().sweepExpiredOrders();
    const iv = setInterval(() => useOrderStore.getState().sweepExpiredOrders(), 15000);
    return () => clearInterval(iv);
  }, []);

  return (
    <div className={theme === 'dark' ? 'theme-dark' : 'theme-light'}>
      <ScrollToTop />
      <Navbar />
      <main className="min-h-screen">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/services" element={<Services />} />
          <Route path="/book" element={<Book />} />
          <Route path="/track" element={<Track />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/auth/login" element={<LoginPage />} />
          <Route path="/auth/signup" element={<SignupPage />} />
          <Route path="/manager/login" element={<ManagerLoginPage />} />
          <Route path="/rider" element={<Navigate to="/rider/dashboard" replace />} />
          <Route path="/rider/dashboard" element={<RiderDashboard />} />
          <Route path="/manager" element={<ManagerDashboard />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/my-orders" element={<MyOrders />} />
        </Routes>
      </main>
      {!isFullScreen && <Footer />}
      {!isFullScreen && <WhatsAppFloat />}
      <ToastContainer />
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AppContent />
    </BrowserRouter>
  );
}
